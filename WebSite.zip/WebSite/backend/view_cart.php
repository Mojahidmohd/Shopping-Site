<?php
require "config.php";

$userId = getUserIdFromToken();
if (!$userId) { http_response_code(401); echo json_encode([]); exit; }

$stmt = $conn->prepare("SELECT id, product_id, name, price, created_at FROM cart WHERE user_id=?");
$stmt->bind_param("s", $userId);
$stmt->execute();
$res = $stmt->get_result();

$rows = [];
while ($row = $res->fetch_assoc()) $rows[] = $row;

header('Content-Type: application/json');
echo json_encode($rows);
?>

