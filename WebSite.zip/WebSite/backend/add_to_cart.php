<?php
require "config.php";

$userId = getUserIdFromToken();
if (!$userId) { http_response_code(401); echo json_encode(["error"=>"Unauthorized"]); exit; }

$data = json_decode(file_get_contents("php://input"), true);
if (!$data || !isset($data['id'], $data['name'], $data['price'])) {
    http_response_code(400);
    echo json_encode(["error"=>"Invalid input"]);
    exit;
}

$stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, name, price) VALUES (?,?,?,?)");
$stmt->bind_param("sisd", $userId, $data['id'], $data['name'], $data['price']);
$ok = $stmt->execute();

header('Content-Type: application/json');
echo json_encode(["success"=>$ok]);
?>

