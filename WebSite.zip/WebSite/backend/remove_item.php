<?php
require "config.php";

$userId = getUserIdFromToken();
if (!$userId) { http_response_code(401); echo json_encode(["error"=>"Unauthorized"]); exit; }

$data = json_decode(file_get_contents("php://input"), true);
if (!$data || !isset($data['id'])) {
    http_response_code(400);
    echo json_encode(["error"=>"Invalid input"]);
    exit;
}

$stmt = $conn->prepare("DELETE FROM cart WHERE id=? AND user_id=?");
$stmt->bind_param("is", $data['id'], $userId);
$ok = $stmt->execute();

header('Content-Type: application/json');
echo json_encode(["success"=>$ok]);
?>

