<?php
require "config.php";

$conn->query("
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  description TEXT,
  image_url VARCHAR(255),
  price DECIMAL(10,2),
  old_price DECIMAL(10,2),
  is_sale BOOLEAN DEFAULT false,
  rating INT DEFAULT 0
)");

$conn->query("
CREATE TABLE IF NOT EXISTS cart (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(100) NOT NULL,
  product_id INT NOT NULL,
  name VARCHAR(100),
  price DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
echo "Tables ready.";
?>

