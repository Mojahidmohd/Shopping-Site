<?php
require "config.php";

$result = $conn->query("SELECT * FROM products");
$rows = [];
while ($row = $result->fetch_assoc()) $rows[] = $row;

header('Content-Type: application/json');
echo json_encode($rows);
?>

