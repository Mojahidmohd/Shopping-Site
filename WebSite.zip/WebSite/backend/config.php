<?php
// DB config
$host = trim(file_get_contents("/etc/rds_endpoint.txt"));
$db   = "shopping";
$user = "admin";
$pass = "admin1234";

// DB connection
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "DB connection failed"]);
    exit;
}

// --- Cognito Helper ---
function getUserIdFromToken() {
    $headers = getallheaders();
    if (!isset($headers['Authorization'])) return null;

    $authHeader = $headers['Authorization'];
    if (!preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) return null;
    $token = $matches[1];

    // Decode JWT (without signature validation for now)
    $parts = explode('.', $token);
    if (count($parts) < 2) return null;
    $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);

    return $payload['sub'] ?? null; // Cognito unique user ID
}
?>

