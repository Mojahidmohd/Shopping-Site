-- Schema for the shopping app
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    description TEXT,
    image_url VARCHAR(255),
    price DECIMAL(10,2),
    old_price DECIMAL(10,2),
    is_sale BOOLEAN DEFAULT false,
    rating INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    product_id INT NULL,
    name VARCHAR(100),
    price DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (user_id)
);

-- Seed products
INSERT INTO products (name, description, image_url, price, old_price, is_sale, rating) VALUES
('Apple', 'Fresh Apple', 'images/Apple-gettyimages-86057185-612x612.jpg', 4.00, NULL, false, 0),
('Orange', 'Juicy Orange', 'images/Orange-gettyimages-158926448-612x612.jpg', 3.00, 20.00, true, 5),
('Mango', 'Sweet Mango', 'images/Mango-gettyimages-1158673231-612x612.jpg', 5.00, 50.00, true, 0),
('Banana', 'Yellow Banana', 'images/Banana-gettyimages-157375066-612x612.jpg', 1.00, NULL, false, 5),
('Cucumber', 'Fresh Cucumber', 'images/Cucumber-gettyimages-1437932233-612x612.jpg', 2.00, 50.00, true, 0),
('Potato', 'Organic Potato', 'images/Potato-gettyimages-57242096-612x612.jpg', 4.00, NULL, false, 0),
('Tomato', 'Red Tomato', 'images/Tomato-gettyimages-518495813-612x612.jpg', 1.00, 20.00, true, 5),
('Eggplant', 'Shiny Eggplant', 'images/Eggplant-gettyimages-594837441-612x612.jpg', 40.00, NULL, false, 5);
